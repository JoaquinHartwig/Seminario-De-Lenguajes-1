namespace TP___03___Punto_3___Seba
{
    partial class Punto_3h
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            label1 = new Label();
            listBoxPares = new ListBox();
            label2 = new Label();
            label3 = new Label();
            txtInicio = new TextBox();
            txtFin = new TextBox();
            lblResultado = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(191, 275);
            button1.Name = "button1";
            button1.Size = new Size(105, 44);
            button1.TabIndex = 0;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(69, 252);
            label1.Name = "label1";
            label1.Size = new Size(395, 20);
            label1.TabIndex = 1;
            label1.Text = "Cálculo del total y visualización de los números aleatorios:";
            // 
            // listBoxPares
            // 
            listBoxPares.FormattingEnabled = true;
            listBoxPares.Location = new Point(482, 75);
            listBoxPares.Name = "listBoxPares";
            listBoxPares.Size = new Size(259, 244);
            listBoxPares.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(69, 97);
            label2.Name = "label2";
            label2.Size = new Size(310, 20);
            label2.TabIndex = 3;
            label2.Text = "Defina el nro de inicio del conjunto aleatorio:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(171, 169);
            label3.Name = "label3";
            label3.Size = new Size(105, 20);
            label3.TabIndex = 4;
            label3.Text = "Defina el final:";
            // 
            // txtInicio
            // 
            txtInicio.Location = new Point(161, 120);
            txtInicio.Name = "txtInicio";
            txtInicio.Size = new Size(125, 27);
            txtInicio.TabIndex = 5;
            // 
            // txtFin
            // 
            txtFin.Location = new Point(162, 192);
            txtFin.Name = "txtFin";
            txtFin.Size = new Size(125, 27);
            txtFin.TabIndex = 6;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(215, 342);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(50, 20);
            lblResultado.TabIndex = 7;
            lblResultado.Text = "label4";
            // 
            // Punto_3h
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblResultado);
            Controls.Add(txtFin);
            Controls.Add(txtInicio);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(listBoxPares);
            Controls.Add(label1);
            Controls.Add(button1);
            Name = "Punto_3h";
            Text = "Punto_3h";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private ListBox listBoxPares;
        private Label label2;
        private Label label3;
        private TextBox txtInicio;
        private TextBox txtFin;
        private Label lblResultado;
    }
}
