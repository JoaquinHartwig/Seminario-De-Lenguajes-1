namespace TP___03___Punto_3___Seba
{
    public partial class Punto_3h : Form
    {
        public Punto_3h()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Validación de entrada usando TryParse
                if (!int.TryParse(txtInicio.Text, out int rangoInicio) || !int.TryParse(txtFin.Text, out int rangoFin))
                {
                    MessageBox.Show("Por favor ingresa números enteros válidos en los campos de rango.", "Entrada inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (rangoInicio < 0 || rangoFin < 0)
                {
                    MessageBox.Show("Por favor ingresa números enteros no negativos.", "Entrada inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (rangoInicio > rangoFin)
                {
                    MessageBox.Show("El valor inicial no puede ser mayor que el valor final.", "Rango inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Caso raro pero posible donde el rango es un sólo número y además impar
                if (rangoInicio == rangoFin && (rangoInicio % 2 != 0))
                {
                    MessageBox.Show("El rango proporcionado no contiene números pares.", "Rango sin pares", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Random aleatorio = new Random();
                int[] numerosPares = new int[10];
                int contadorPares = 0;
                int sumaTotal = 0;

                // Se limpia la lista en caso de que el usuario haga click varias veces
                listBoxPares.Items.Clear();

                while (contadorPares < 10)
                {
                    // Se pone +1 porque el método Next no incluye el valor máximo, entonces para incluirlo se suma 1
                    int numero = aleatorio.Next(rangoInicio, rangoFin + 1);

                    if (numero % 2 == 0)
                    {
                        numerosPares[contadorPares] = numero;
                        sumaTotal += numero;
                        listBoxPares.Items.Add(numero);
                        contadorPares++;
                    }
                }

                // Mostrar suma total una vez que se han generado los 10 pares
                lblResultado.Text = "La suma de los 10 pares es: " + sumaTotal.ToString();
            }
            catch (Exception ex)
            {
                // Manejo general de excepciones para practicar try/catch
                MessageBox.Show("Ocurrió un error inesperado: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
