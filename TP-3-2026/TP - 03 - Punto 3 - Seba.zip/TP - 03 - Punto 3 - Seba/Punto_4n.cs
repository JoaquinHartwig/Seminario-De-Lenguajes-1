﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TP___03___Punto_3___Seba
{
    public partial class Punto_4n : Form
    {
        public Punto_4n()
        {
            InitializeComponent();
        }

        List<double> listaNumeros = new List<double>();

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                double numeroIngresado = double.Parse(txtNumero.Text);

                listaNumeros.Add(numeroIngresado);

                lblContador.Text = $"Total de números cargados: {listaNumeros.Count}";

                txtNumero.Clear();
                txtNumero.Focus();
            }
            catch (Exception)
            {
                MessageBox.Show("Por favor, ingrese un número válido (ej: 14, -5, 3.14).", "Error de formato");
            }
        }

        private void btnOrdenar_Click(object sender, EventArgs e)
        {
            if (listaNumeros.Count == 0)
            {
                MessageBox.Show("Debe agregar al menos un número antes de ordenar.");
                return;
            }

            lstMenorAMayor.Items.Clear();
            lstMayorAMenor.Items.Clear();

            listaNumeros.Sort();

            foreach (double numero in listaNumeros)
            {
                lstMenorAMayor.Items.Add(numero);
            }

            listaNumeros.Reverse();

            foreach (double numero in listaNumeros)
            {
                lstMayorAMenor.Items.Add(numero);
            }
        }
    }
}
