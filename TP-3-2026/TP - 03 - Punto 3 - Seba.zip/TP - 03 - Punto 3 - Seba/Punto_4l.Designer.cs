﻿namespace TP___03___Punto_3___Seba
{
    partial class Punto_4l
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCalcularDias = new Button();
            txtMes = new TextBox();
            txtAnio = new TextBox();
            label1 = new Label();
            lblAnio = new Label();
            lblResultado = new Label();
            SuspendLayout();
            // 
            // btnCalcularDias
            // 
            btnCalcularDias.AutoSize = true;
            btnCalcularDias.Location = new Point(293, 226);
            btnCalcularDias.Name = "btnCalcularDias";
            btnCalcularDias.Size = new Size(105, 50);
            btnCalcularDias.TabIndex = 0;
            btnCalcularDias.Text = "Calcular Días";
            btnCalcularDias.UseVisualStyleBackColor = true;
            btnCalcularDias.Click += btnCalcularDias_Click;
            // 
            // txtMes
            // 
            txtMes.Location = new Point(438, 123);
            txtMes.Name = "txtMes";
            txtMes.Size = new Size(50, 27);
            txtMes.TabIndex = 1;
            txtMes.TextChanged += txtMes_TextChanged;
            // 
            // txtAnio
            // 
            txtAnio.Location = new Point(455, 177);
            txtAnio.Name = "txtAnio";
            txtAnio.Size = new Size(66, 27);
            txtAnio.TabIndex = 2;
            txtAnio.Visible = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(202, 126);
            label1.Name = "label1";
            label1.Size = new Size(230, 20);
            label1.TabIndex = 3;
            label1.Text = "Cargue el número del mes (1-12):";
            // 
            // lblAnio
            // 
            lblAnio.AutoSize = true;
            lblAnio.Location = new Point(168, 180);
            lblAnio.Name = "lblAnio";
            lblAnio.Size = new Size(281, 20);
            lblAnio.TabIndex = 4;
            lblAnio.Text = "Cargue el año actual para poder calcular:";
            lblAnio.Visible = false;
            // 
            // lblResultado
            // 
            lblResultado.Location = new Point(100, 286);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(502, 20);
            lblResultado.TabIndex = 5;
            lblResultado.Text = ".";
            lblResultado.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Punto_4l
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblResultado);
            Controls.Add(lblAnio);
            Controls.Add(label1);
            Controls.Add(txtAnio);
            Controls.Add(txtMes);
            Controls.Add(btnCalcularDias);
            Name = "Punto_4l";
            Text = "Punto_4l";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCalcularDias;
        private TextBox txtMes;
        private TextBox txtAnio;
        private Label label1;
        private Label lblAnio;
        private Label lblResultado;
    }
}