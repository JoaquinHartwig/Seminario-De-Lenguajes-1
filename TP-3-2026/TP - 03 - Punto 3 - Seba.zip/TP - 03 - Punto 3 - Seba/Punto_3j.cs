﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TP___03___Punto_3___Seba
{
    public partial class Punto_3j : Form
    {
        public Punto_3j()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                int numero = int.Parse(txtNumero.Text);

                if (numero >= 0)
                {
                    long resultado = 1;
                    for (int i = 1; i <= numero; i++)
                    {
                        resultado *= i;
                    }

                    lblResultado.Text = $"El factorial de {numero} es: {resultado}";
                }
                else
                {
                    MessageBox.Show("Por favor, ingrese un número entero no negativo.", "Entrada inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtNumero.Clear();
                    txtNumero.Focus();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Por favor, ingrese solamente números enteros.", "Entrada inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNumero.Clear();
                txtNumero.Focus();
            }
        }
    }
}
