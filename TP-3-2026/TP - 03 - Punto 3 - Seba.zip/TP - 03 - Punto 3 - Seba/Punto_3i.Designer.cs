﻿namespace TP___03___Punto_3___Seba
{
    partial class Punto_3i
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAgregar = new Button();
            label1 = new Label();
            txtCantAlu = new TextBox();
            txtNota = new TextBox();
            label2 = new Label();
            lblSumaNotas = new Label();
            lblPromedio = new Label();
            label3 = new Label();
            label4 = new Label();
            SuspendLayout();
            // 
            // btnAgregar
            // 
            btnAgregar.Location = new Point(204, 274);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(110, 58);
            btnAgregar.TabIndex = 0;
            btnAgregar.Text = "Agregar y Calcular";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(148, 98);
            label1.Name = "label1";
            label1.Size = new Size(218, 20);
            label1.TabIndex = 1;
            label1.Text = "Cargue la cantidad de alumnos:";
            // 
            // txtCantAlu
            // 
            txtCantAlu.Location = new Point(220, 121);
            txtCantAlu.Name = "txtCantAlu";
            txtCantAlu.Size = new Size(65, 27);
            txtCantAlu.TabIndex = 2;
            // 
            // txtNota
            // 
            txtNota.Location = new Point(220, 206);
            txtNota.Name = "txtNota";
            txtNota.Size = new Size(64, 27);
            txtNota.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(204, 183);
            label2.Name = "label2";
            label2.Size = new Size(109, 20);
            label2.TabIndex = 3;
            label2.Text = "Cargue la nota:";
            // 
            // lblSumaNotas
            // 
            lblSumaNotas.AutoSize = true;
            lblSumaNotas.Location = new Point(421, 169);
            lblSumaNotas.Name = "lblSumaNotas";
            lblSumaNotas.Size = new Size(12, 20);
            lblSumaNotas.TabIndex = 5;
            lblSumaNotas.Text = ".";
            // 
            // lblPromedio
            // 
            lblPromedio.AutoSize = true;
            lblPromedio.Location = new Point(421, 254);
            lblPromedio.Name = "lblPromedio";
            lblPromedio.Size = new Size(12, 20);
            lblPromedio.TabIndex = 6;
            lblPromedio.Text = ".";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(390, 149);
            label3.Name = "label3";
            label3.Size = new Size(113, 20);
            label3.TabIndex = 7;
            label3.Text = "Suma de Notas:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(410, 234);
            label4.Name = "label4";
            label4.Size = new Size(77, 20);
            label4.TabIndex = 8;
            label4.Text = "Promedio:";
            // 
            // Punto_3i
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(lblPromedio);
            Controls.Add(lblSumaNotas);
            Controls.Add(txtNota);
            Controls.Add(label2);
            Controls.Add(txtCantAlu);
            Controls.Add(label1);
            Controls.Add(btnAgregar);
            Name = "Punto_3i";
            Text = "Punto_3i";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAgregar;
        private Label label1;
        private TextBox txtCantAlu;
        private TextBox txtNota;
        private Label label2;
        private Label lblSumaNotas;
        private Label lblPromedio;
        private Label label3;
        private Label label4;
    }
}