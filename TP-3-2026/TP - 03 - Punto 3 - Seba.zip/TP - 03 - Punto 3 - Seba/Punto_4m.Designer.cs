﻿namespace TP___03___Punto_3___Seba
{
    partial class Punto_4m
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnDia = new Button();
            label1 = new Label();
            txtDia = new TextBox();
            lblResultado = new Label();
            SuspendLayout();
            // 
            // btnDia
            // 
            btnDia.Location = new Point(330, 174);
            btnDia.Name = "btnDia";
            btnDia.Size = new Size(94, 51);
            btnDia.TabIndex = 0;
            btnDia.Text = "Calcular Día";
            btnDia.UseVisualStyleBackColor = true;
            btnDia.Click += btnDia_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(233, 107);
            label1.Name = "label1";
            label1.Size = new Size(273, 20);
            label1.TabIndex = 1;
            label1.Text = "Ingrese el número del día de la semana:";
            // 
            // txtDia
            // 
            txtDia.Location = new Point(350, 130);
            txtDia.Name = "txtDia";
            txtDia.Size = new Size(55, 27);
            txtDia.TabIndex = 2;
            // 
            // lblResultado
            // 
            lblResultado.Location = new Point(233, 228);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(280, 25);
            lblResultado.TabIndex = 3;
            lblResultado.Text = ".";
            lblResultado.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Punto_4m
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblResultado);
            Controls.Add(txtDia);
            Controls.Add(label1);
            Controls.Add(btnDia);
            Name = "Punto_4m";
            Text = "Punto_4m";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnDia;
        private Label label1;
        private TextBox txtDia;
        private Label lblResultado;
    }
}