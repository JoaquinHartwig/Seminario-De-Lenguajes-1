﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TP___03___Punto_3___Seba
{
    public partial class Punto_4k : Form
    {
        public Punto_4k()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int puntuacion = int.Parse(txtPuntuacion.Text);
                string calificación = "";

                switch (puntuacion)
                {
                    case >= 90 and <= 100:
                        calificación = "A";
                        break;
                    case >= 80 and <= 89:
                        calificación = "B";
                        break;
                    case >= 70 and <= 79:
                        calificación = "C";
                        break;
                    case >= 60 and <= 69:
                        calificación = "D";
                        break;
                    case >= 40 and <= 59:
                        calificación = "E";
                        break;
                    case >= 0 and <= 39:
                        calificación = "F";
                        break;
                    default:
                        MessageBox.Show("Puntuación fuera de rango. Ingrese un valor entre 0 y 100.");
                        return;
                }
                lblResultado.Text = $"La calificación final es: {calificación}";
            }
            catch (Exception)
            {
                MessageBox.Show("Ingrese un valor numérico válido para la puntuación.");
                return;
            }
        }
    }
}
