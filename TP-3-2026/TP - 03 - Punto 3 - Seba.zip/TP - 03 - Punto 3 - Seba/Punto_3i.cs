﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TP___03___Punto_3___Seba
{
    public partial class Punto_3i : Form
    {
        public Punto_3i()
        {
            InitializeComponent();
        }

        int cantNota = 0;
        double sumaNotas = 0;

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            try 
            {
                int limiteN = int.Parse(txtCantAlu.Text);

                if (cantNota < limiteN)
                {
                    double nota = double.Parse(txtNota.Text);
                    if (nota >= 1 && nota <= 100)
                    {
                        sumaNotas = sumaNotas + nota;
                        cantNota++;

                        double notaMedia = sumaNotas / cantNota;
                        lblSumaNotas.Text = sumaNotas.ToString();
                        lblPromedio.Text = notaMedia.ToString("F2");

                        txtNota.Clear();
                        txtNota.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Por favor, ingrese una nota válida entre 1 y 100.", "Fuera de Rango");
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error: Debe ingresar un valor numérico.", "Entrada Inválida");
            }
        }
    }
}
