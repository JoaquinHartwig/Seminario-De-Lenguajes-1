﻿namespace TP___03___Punto_3___Seba
{
    partial class Punto_4k
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtPuntuacion = new TextBox();
            lblResultado = new Label();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(290, 117);
            label1.Name = "label1";
            label1.Size = new Size(155, 20);
            label1.TabIndex = 0;
            label1.Text = "Cargue su puntuación:";
            // 
            // txtPuntuacion
            // 
            txtPuntuacion.Location = new Point(344, 140);
            txtPuntuacion.Name = "txtPuntuacion";
            txtPuntuacion.Size = new Size(56, 27);
            txtPuntuacion.TabIndex = 1;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(290, 211);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(12, 20);
            lblResultado.TabIndex = 2;
            lblResultado.Text = ".";
            // 
            // button1
            // 
            button1.Location = new Point(323, 173);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 3;
            button1.Text = "Calificar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Punto_4k
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(lblResultado);
            Controls.Add(txtPuntuacion);
            Controls.Add(label1);
            Name = "Punto_4k";
            Text = "Punto_4k";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtPuntuacion;
        private Label lblResultado;
        private Button button1;
    }
}