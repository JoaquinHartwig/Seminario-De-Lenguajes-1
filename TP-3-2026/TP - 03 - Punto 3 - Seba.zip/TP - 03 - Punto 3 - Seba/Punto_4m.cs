﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TP___03___Punto_3___Seba
{
    public partial class Punto_4m : Form
    {
        public Punto_4m()
        {
            InitializeComponent();
        }

        private void btnDia_Click(object sender, EventArgs e)
        {
            try
            {
                int dia = int.Parse(txtDia.Text);
                string nombreDia = "";

                switch (dia)
                {
                    case 1:
                        nombreDia = "Lunes";
                        break;
                    case 2:
                        nombreDia = "Martes";
                        break;
                    case 3:
                        nombreDia = "Miércoles";
                        break;
                    case 4:
                        nombreDia = "Jueves";
                        break;
                    case 5:
                        nombreDia = "Viernes";
                        break;
                    case 6:
                        nombreDia = "Sábado";
                        break;
                    case 7:
                        nombreDia = "Domingo";
                        break;
                    default:
                        MessageBox.Show("Por favor, ingrese un número del 1 al 7.");
                        txtDia.Clear();
                        txtDia.Focus();
                        return;
                }

                lblResultado.Text = $"El día {dia} corresponde al {nombreDia}.";
            }
            catch (Exception)
            {
                MessageBox.Show("Ingrese un número entero válido.");
            }
        }
    }
}
