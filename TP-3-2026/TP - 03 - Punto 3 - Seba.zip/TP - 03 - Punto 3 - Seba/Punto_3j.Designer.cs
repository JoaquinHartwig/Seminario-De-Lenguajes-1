﻿namespace TP___03___Punto_3___Seba
{
    partial class Punto_3j
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCalcular = new Button();
            label1 = new Label();
            txtNumero = new TextBox();
            lblResultado = new Label();
            SuspendLayout();
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(368, 166);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(94, 49);
            btnCalcular.TabIndex = 0;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(136, 165);
            label1.Name = "label1";
            label1.Size = new Size(197, 20);
            label1.TabIndex = 1;
            label1.Text = "Cargue el número a calcular:";
            // 
            // txtNumero
            // 
            txtNumero.Location = new Point(199, 188);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(64, 27);
            txtNumero.TabIndex = 3;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(233, 242);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(12, 20);
            lblResultado.TabIndex = 4;
            lblResultado.Text = ".";
            // 
            // Punto_3j
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblResultado);
            Controls.Add(txtNumero);
            Controls.Add(label1);
            Controls.Add(btnCalcular);
            Name = "Punto_3j";
            Text = "Punto_3j";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCalcular;
        private Label label1;
        private TextBox txtNumero;
        private Label lblResultado;
    }
}