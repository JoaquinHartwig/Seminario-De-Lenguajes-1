﻿namespace TP___03___Punto_3___Seba
{
    partial class Punto_4n
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAgregar = new Button();
            txtNumero = new TextBox();
            lstMenorAMayor = new ListBox();
            lstMayorAMenor = new ListBox();
            btnOrdenar = new Button();
            label1 = new Label();
            lblContador = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // btnAgregar
            // 
            btnAgregar.Location = new Point(357, 108);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(94, 29);
            btnAgregar.TabIndex = 0;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // txtNumero
            // 
            txtNumero.Location = new Point(342, 64);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(124, 27);
            txtNumero.TabIndex = 1;
            // 
            // lstMenorAMayor
            // 
            lstMenorAMayor.FormattingEnabled = true;
            lstMenorAMayor.Location = new Point(170, 234);
            lstMenorAMayor.Name = "lstMenorAMayor";
            lstMenorAMayor.Size = new Size(179, 164);
            lstMenorAMayor.TabIndex = 2;
            // 
            // lstMayorAMenor
            // 
            lstMayorAMenor.FormattingEnabled = true;
            lstMayorAMenor.Location = new Point(446, 234);
            lstMayorAMenor.Name = "lstMayorAMenor";
            lstMayorAMenor.Size = new Size(179, 164);
            lstMayorAMenor.TabIndex = 3;
            // 
            // btnOrdenar
            // 
            btnOrdenar.Location = new Point(325, 182);
            btnOrdenar.Name = "btnOrdenar";
            btnOrdenar.Size = new Size(160, 29);
            btnOrdenar.TabIndex = 4;
            btnOrdenar.Text = "Ordenar Listas";
            btnOrdenar.UseVisualStyleBackColor = true;
            btnOrdenar.Click += btnOrdenar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(267, 21);
            label1.Name = "label1";
            label1.Size = new Size(277, 20);
            label1.TabIndex = 5;
            label1.Text = "Cargue el número a introducir en la lista:";
            // 
            // lblContador
            // 
            lblContador.Location = new Point(236, 140);
            lblContador.Name = "lblContador";
            lblContador.Size = new Size(337, 25);
            lblContador.TabIndex = 6;
            lblContador.Text = ".";
            lblContador.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(283, 41);
            label2.Name = "label2";
            label2.Size = new Size(243, 20);
            label2.TabIndex = 7;
            label2.Text = "(números decimales van con coma)";
            // 
            // Punto_4n
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(lblContador);
            Controls.Add(label1);
            Controls.Add(btnOrdenar);
            Controls.Add(lstMayorAMenor);
            Controls.Add(lstMenorAMayor);
            Controls.Add(txtNumero);
            Controls.Add(btnAgregar);
            Name = "Punto_4n";
            Text = "Punto_4n";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAgregar;
        private TextBox txtNumero;
        private ListBox lstMenorAMayor;
        private ListBox lstMayorAMenor;
        private Button btnOrdenar;
        private Label label1;
        private Label lblContador;
        private Label label2;
    }
}