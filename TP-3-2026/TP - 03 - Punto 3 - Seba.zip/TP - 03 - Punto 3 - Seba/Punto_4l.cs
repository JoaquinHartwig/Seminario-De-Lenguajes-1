﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TP___03___Punto_3___Seba
{
    public partial class Punto_4l : Form
    {
        public Punto_4l()
        {
            InitializeComponent();
        }

        private void txtMes_TextChanged(object sender, EventArgs e)
        {
            if (txtMes.Text == "2")
            {
                txtAnio.Visible = true;
                lblAnio.Visible = true;

                txtAnio.Focus();
            }
            else
            {
                txtAnio.Visible = false;
                lblAnio.Visible = false;

                txtAnio.Clear();
            }
        }

        private void btnCalcularDias_Click(object sender, EventArgs e)
        {
            try
            {
                int mes = int.Parse(txtMes.Text);
                int dias = 0;

                switch (mes)
                {
                    case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                        dias = 31;
                        lblResultado.Text = $"El mes {mes} tiene {dias} días.";
                        break;
                    case 4: case 6: case 9: case 11:
                        dias = 30;
                        lblResultado.Text = $"El mes {mes} tiene {dias} días.";
                        break;
                    case 2:
                        
                        if (string.IsNullOrEmpty(txtAnio.Text))
                        {
                            MessageBox.Show("Para el mes de febrero se debe ingresar el año para poder calcular.", "Dato Faltante");
                            txtAnio.Focus();
                            return;
                        }

                        int anio = int.Parse(txtAnio.Text);

                        if ((anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0))
                        {
                            dias = 29;
                        }
                        else
                        {
                            dias = 28;
                        }

                        lblResultado.Text = $"El mes de Febrero del año {anio} tiene {dias} días.";
                        break;
                    default:
                        MessageBox.Show("Por favor, ingrese un número de mes válido (1-12).");
                        break;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Por favor, ingrese valores numéricos enteros.");
            }
        }
    }
}
