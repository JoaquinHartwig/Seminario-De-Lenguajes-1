﻿namespace Parcial_Practico_Joaquin_Hartwig
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            listBox1 = new ListBox();
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            textBox2 = new TextBox();
            button2 = new Button();
            listBox2 = new ListBox();
            button3 = new Button();
            listBox3 = new ListBox();
            label3 = new Label();
            label4 = new Label();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(118, 126);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 0;
            // 
            // listBox1
            // 
            listBox1.BackColor = Color.Lime;
            listBox1.FormattingEnabled = true;
            listBox1.Location = new Point(118, 236);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(110, 169);
            listBox1.TabIndex = 1;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(255, 128, 255);
            button1.Location = new Point(118, 164);
            button1.Name = "button1";
            button1.Size = new Size(90, 51);
            button1.TabIndex = 2;
            button1.Text = "Agregar Letra";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Showcard Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(138, 82);
            label1.Name = "label1";
            label1.Size = new Size(55, 17);
            label1.TabIndex = 3;
            label1.Text = "Letras";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Showcard Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(332, 82);
            label2.Name = "label2";
            label2.Size = new Size(71, 17);
            label2.TabIndex = 4;
            label2.Text = "Números";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(324, 126);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 5;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(255, 128, 255);
            button2.Location = new Point(332, 164);
            button2.Name = "button2";
            button2.Size = new Size(90, 51);
            button2.TabIndex = 6;
            button2.Text = "Agregar Números";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // listBox2
            // 
            listBox2.BackColor = Color.FromArgb(255, 128, 0);
            listBox2.FormattingEnabled = true;
            listBox2.Location = new Point(324, 236);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(110, 169);
            listBox2.TabIndex = 7;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(255, 128, 255);
            button3.Location = new Point(513, 164);
            button3.Name = "button3";
            button3.Size = new Size(90, 51);
            button3.TabIndex = 8;
            button3.Text = "Generar";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // listBox3
            // 
            listBox3.BackColor = Color.FromArgb(255, 128, 255);
            listBox3.FormattingEnabled = true;
            listBox3.Location = new Point(513, 236);
            listBox3.Name = "listBox3";
            listBox3.Size = new Size(110, 169);
            listBox3.TabIndex = 9;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(208, 19);
            label3.Name = "label3";
            label3.Size = new Size(214, 22);
            label3.TabIndex = 10;
            label3.Text = "Examen Parcial:Practica";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(494, 23);
            label4.Name = "label4";
            label4.Size = new Size(202, 18);
            label4.TabIndex = 11;
            label4.Text = "Estudiante: Hartwig Joaquin";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(listBox3);
            Controls.Add(button3);
            Controls.Add(listBox2);
            Controls.Add(button2);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(listBox1);
            Controls.Add(textBox1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private ListBox listBox1;
        private Button button1;
        private Label label1;
        private Label label2;
        private TextBox textBox2;
        private Button button2;
        private ListBox listBox2;
        private Button button3;
        private ListBox listBox3;
        private Label label3;
        private Label label4;
    }
}
