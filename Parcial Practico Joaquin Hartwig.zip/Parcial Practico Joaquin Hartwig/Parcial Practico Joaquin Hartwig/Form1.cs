namespace Parcial_Practico_Joaquin_Hartwig
{
    public partial class Form1 : Form
    {
        public char[] letras = new char[5];
        public int[] numeros = new int[5];
        public string[] datos = new string[5];
        int contLetras = 0;
        int contNumeros = 0;

        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (contLetras >= 5)
                {
                    MessageBox.Show("El array de letras ya está lleno");
                    return;
                }

                if (textBox1.Text.Length != 1)
                {
                    MessageBox.Show("Ingresá un solo carácter");
                    return;
                }
                if (!char.IsLetter(textBox1.Text[0]))
                {
                    MessageBox.Show("Solo se permiten letras");
                    return;
                }

                letras[contLetras] = char.Parse(textBox1.Text);
                listBox1.Items.Add(letras[contLetras]);
                contLetras++;
                textBox1.Clear();
                textBox1.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (contNumeros >= 5)
                {
                    MessageBox.Show("El array de números ya está lleno");
                    return;
                }

                int numero;

                if (!int.TryParse(textBox2.Text, out numero))
                {
                    MessageBox.Show("Solo se permiten números.");
                    return;
                }

                numeros[contNumeros] = numero;
                listBox2.Items.Add(numeros[contNumeros]);
                contNumeros++;
                textBox2.Clear();
                textBox2.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void Generar(char[] arr1, int[] arr2)
        {
            for (int i = 0; i < 5; i++)
            {
                datos[i] = arr1[i].ToString() + arr2[i].ToString();
                listBox3.Items.Add(datos[i]);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    if (contLetras < 5 || contNumeros < 5)
                    {
                        MessageBox.Show("Cargá los 5 elementos de cada array primero");
                        return;
                    }

                    listBox3.Items.Clear();
                    Generar(letras, numeros);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
    }
}


